#!/bin/bash
cd /root/BlueHorseshoe
docker exec bluehorseshoe python src/run_isolated_indicator_test.py \
    --indicator BB \
    --multiplier 1.5 \
    --runs 20 \
    --strategy mean_reversion \
    --name bb_mr_boosted
