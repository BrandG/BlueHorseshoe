#!/bin/bash
cd /root/BlueHorseshoe
docker exec bluehorseshoe python src/run_isolated_indicator_test.py \
    --indicator BELT_HOLD \
    --multiplier 0.5 \
    --runs 20 \
    --name belt_hold_reduced
