#!/bin/bash
cd /root/BlueHorseshoe
docker exec bluehorseshoe python src/run_isolated_indicator_test.py \
    --indicator MA_DIST \
    --multiplier 0.5 \
    --runs 20 \
    --strategy mean_reversion \
    --name ma_dist_mr_reduced
