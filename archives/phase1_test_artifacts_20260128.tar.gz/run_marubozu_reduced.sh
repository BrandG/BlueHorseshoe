#!/bin/bash
cd /root/BlueHorseshoe
docker exec bluehorseshoe python src/run_isolated_indicator_test.py \
    --indicator MARUBOZU \
    --multiplier 0.5 \
    --runs 20 \
    --name marubozu_reduced
