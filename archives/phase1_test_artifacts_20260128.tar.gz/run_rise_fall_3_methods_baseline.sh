#!/bin/bash
cd /root/BlueHorseshoe
docker exec bluehorseshoe python src/run_isolated_indicator_test.py \
    --indicator RISE_FALL_3_METHODS \
    --multiplier 1.0 \
    --runs 20 \
    --name rise_fall_3_methods_baseline
